BEASTLabs: BEAST 2 (http://beast2.org) package containing some generally useful stuff used by other packages.
